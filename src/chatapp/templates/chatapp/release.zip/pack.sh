7zz a release.zip ./* -xr\!eletron -x\!package.json -x\!README.md
